package TokioSchool;

public class Principal {
    public static void main(String []args){

        ArrayCharSequenceTokio caracteres = new ArrayCharSequenceTokio('s','g','l','e','t','k','u');
        BackwardsStringCharSequenceTokio frase = new BackwardsStringCharSequenceTokio("hola que tal estas");


        System.out.println(caracteres.length());
        System.out.println(caracteres.charAt(5));
        System.out.println(caracteres.subSecuence(2,5));
        System.out.println(caracteres.toString());
        System.out.println("---------------------------");
        System.out.println(frase.length());
        System.out.println(frase.charAt(15));
        System.out.println(frase.subSecuence(1,10));
        System.out.println(frase.toString());
    }
}