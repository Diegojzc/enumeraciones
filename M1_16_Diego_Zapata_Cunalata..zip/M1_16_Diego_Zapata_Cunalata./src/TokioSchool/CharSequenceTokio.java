package TokioSchool;

public interface CharSequenceTokio {


     public abstract int length();

     public abstract char charAt(int index);

     public abstract CharSequenceTokio subSecuence(int start, int end);

     public abstract  String toString();


}

