package TokioSchool;

import java.nio.charset.StandardCharsets;

public class BackwardsStringCharSequenceTokio implements CharSequenceTokio {


    private  String frase;

    public BackwardsStringCharSequenceTokio(){}
    public BackwardsStringCharSequenceTokio(String frase) {

        String nueva = "";
        for (int i = frase.length() - 1; i >= 0; i--) {
            char actual = frase.charAt(i);
            nueva += actual;
            this.frase = nueva;
        }

    }

    @Override
    public int length() {
        return frase.length();
    }

    @Override
    public char charAt(int index) {

        if (index < 0 || index > frase.length() - 1) {
            return '0';
        }
        String cadena = frase;
        return cadena.charAt(index);

    }

    @Override
    public CharSequenceTokio subSecuence(int start, int end) {

        if (start < 0 || end > frase.length()){
            return null;

        }if(start > end){
            return null;
        }

        BackwardsStringCharSequenceTokio backwardsStringCharSequenceTokio= new BackwardsStringCharSequenceTokio();
        backwardsStringCharSequenceTokio.frase = new String(frase);
        for (int i = start; i <end ; i++) {

            backwardsStringCharSequenceTokio.frase=frase.substring(start,end);
        }
        return  backwardsStringCharSequenceTokio ;
    }


    @Override
    public String toString() {
        return "BackwardsStringCharSequenceTokio{" +
                "frase='" + frase + '\'' +
                '}';
    }
}