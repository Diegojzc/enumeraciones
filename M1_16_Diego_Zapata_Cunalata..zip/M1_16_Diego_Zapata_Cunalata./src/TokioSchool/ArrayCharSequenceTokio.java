package TokioSchool;

import java.util.Arrays;

public class ArrayCharSequenceTokio implements CharSequenceTokio {

    char[] caracteres;

    public ArrayCharSequenceTokio(char... caracteres) {
        this.caracteres = caracteres;

    }


    @Override
    public int length() {
        return caracteres.length;
    }


    @Override
    public char charAt(int index) {

        if (index < 0 || index > caracteres.length) {

            return '0';
        }


        return caracteres[index];

    }

    @Override
    public CharSequenceTokio subSecuence(int start, int end) {


        if(start < 0 || end > caracteres.length){
            return null;
        }if (start > end){
            return null;
        }

        ArrayCharSequenceTokio arrayCharSequenceTokio = new ArrayCharSequenceTokio();
        arrayCharSequenceTokio.caracteres = new char[end-start];
        for (int i = start; i < end ; i++) {

            arrayCharSequenceTokio.caracteres[i-start] = caracteres[i];
        }

        return arrayCharSequenceTokio ;

    }


    @Override
    public String toString() {
        return "ArrayCharSequenceTokio{" +
                "caracteres=" + Arrays.toString(caracteres) +
                '}';
    }


}



